#include <iocc2530.h>

void uart0_init(void)
{//USART0ѡ��uartģʽ���ܽ�ΪP0,���ݸ�ʽΪ8λ����λ��1λֹͣλ��û��У��λ
  //������Ϊ115200��LSB����ģʽ��1Ϊֹͣ��0Ϊ��ʼ
  PERCFG&=~0X1;
  P2DIR&=~(0X3<<6);
  P0SEL|=(0X3<<2);
   U0CSR |= 0x80;//U0CSR=(1<<7)|(1<<6);
  U0GCR=11;
  U0BAUD=216;U0CSR |= 0x40;
  UTX0IF=0;

  URX0IF=0;
  URX0IE=1;  
}

void uart1_init(void)
{
  PERCFG|=(1<<1);
 P2SEL|=(1<<6);
  P1SEL|=(0X3<<6);
   U1CSR |= (1<<7);
  U1GCR=11;
  U1BAUD=216;U1CSR |= 0x40;
  UTX1IF=0;

  URX1IF=0;
  URX1IE=1;  
}

void uart0_send_byte(char tmp)
{
       U0DBUF = tmp;
  while(UTX0IF == 0);
  UTX0IF = 0;
      
      
}
void uart1_send_byte(char tmp)
{  
       U1DBUF = tmp;
  while(UTX1IF == 0);
  UTX1IF = 0;
      
      
}
void uart0_send_str(char *pStr)
{
  while(*pStr!='\0')
  {
    uart0_send_byte(*pStr++);
  }
}
void uart1_send_str(char *pStr)
{
  while(*pStr!='\0')
  {
    uart1_send_byte(*pStr++);
  }
}

/*#pragma vector=0x13
__interrupt void uart0_receive_isr(void)
{
  unsigned char duty;
  duty=U0DBUF;
  uart1_send_byte(duty);
}*/
