#ifndef __UART_H__
#define __UART_H__

extern void uart0_init(void);
extern void uart0_send_byte(char tmp);
extern void uart0_send_str(char *pStr);
extern void uart1_init(void);
extern void uart1_send_byte(char tmp);
extern void uart1_send_str(char *pStr);




#endif

